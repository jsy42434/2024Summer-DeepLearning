# box_total > 2024-07-11 6:29am
https://universe.roboflow.com/box-lszh9/box_total

Provided by a Roboflow user
License: CC BY 4.0

